I will add to this folder a few examples of OpenCV and practice with the GitHub functionalities 
