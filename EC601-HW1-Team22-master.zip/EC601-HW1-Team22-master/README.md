# EC601-HW1-Team22
Team 22 Mini Project for Homework 1

# Team Members
- Davide Lucchi
- Sami Shahin
- Tianyi Zhang

# Project Name (TBD)
